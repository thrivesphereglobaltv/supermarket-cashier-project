# 🛒 Supermarket Cashier Project

A Python program by **ThriveSphere Global TV** that simulates a supermarket billing system with membership-based discounts.
This interactive script allows users to add products, compute totals, and apply discounts automatically.

## 🚀 Features
- Add multiple products with their quantities  
- Automatically calculate total and apply membership discounts  
- Supports three membership tiers: Gold, Silver, and Bronze  
- User-friendly, interactive console interface  

## 🧮 Membership Discounts
| Membership | Discount |
|-------------|-----------|
| Gold        | 20%       |
| Silver      | 10%       |
| Bronze      | 5%        |

> *No discount is applied on purchases below $25.*

## 💻 How to Run
1. Clone or download this repository  
2. Open a terminal or command prompt in the project folder  
3. Run the script using:
   ```bash
   python supermarket_cashier.py
   ```

## 📊 Example Output
```
Press A to add product and Q to quit: A
Enter product: Biscuit
Enter quantity: 5
Press A to add product and Q to quit: A
Enter product: Coke
Enter quantity: 3
Press A to add product and Q to quit: Q
Enter customer membership: Gold
Biscuit:$3x5=15
Coke:$2x3=6
20% off for Gold membership on total amount: $16.8
The discounted amount is $16.8
```

## 🧰 Technologies Used
- Python 3.x

## 📜 License
This project is licensed under the **MIT License** — free for educational and commercial use.

**Developed by ThriveSphere Global TV**
